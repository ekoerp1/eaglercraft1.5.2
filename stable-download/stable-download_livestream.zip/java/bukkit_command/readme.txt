
DO NOT IGNORE THIS MESSAGE, USE YOUR BRAIN AND READ!

Bukkit is a piece of shit, if you "/op LAX1DUDE", a player joining as 'laX1DUDE' or 'LaX1dUdE' or 'lax1dude' will all have /op too

Either don't use /op and install an actual permissions plugin, or move "BitchFilerPlugin.jar" into this server's "/plugins" folder and use only lowercase letters in your /op profile names!

Again, if you install the bitchfilter plugin, you need to /op yourself with  ALL LOWERCASE LETTERS like "/op lax1dude", and then when you want to join as an op you don't type 'LAX1DUDE' you have to join as 'lax1dude' or you will be kicked by the plugin for security

PLEASE PLEASE PLEASE DO NOT IGNORE THIS MESSAGE!!!

IF YOU IGNORE THIS AND USE /op WITH MIXED CASE THEN YOU WILL BE HACKED!!!

DO NOT MAKE THIS MISTAKE OR YOU CAN LOSE YOUR WHOLE SERVER IN MINUTES!!!